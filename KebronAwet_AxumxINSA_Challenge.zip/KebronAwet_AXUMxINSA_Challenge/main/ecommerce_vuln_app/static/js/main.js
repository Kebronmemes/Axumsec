// Main JavaScript for the e-commerce app

// Store auth token for API requests
let authToken = null;

document.addEventListener('DOMContentLoaded', function() {
    // Check for auth token in session
    if (typeof sessionStorage !== 'undefined') {
        authToken = sessionStorage.getItem('auth_token');
    }
    
    // Set up API request headers if token exists
    if (authToken) {
        // This will be used by fetch requests
        window.authToken = authToken;
    }
    
    // Initialize tooltips
    const tooltips = document.querySelectorAll('[data-tooltip]');
    tooltips.forEach(element => {
        element.addEventListener('mouseenter', showTooltip);
        element.addEventListener('mouseleave', hideTooltip);
    });
    
    // Product page specific - extract hidden UUID
    if (window.location.pathname.includes('/product/')) {
        extractSellerUUID();
    }
});

function extractSellerUUID() {
    // This simulates how an attacker might extract hidden UUIDs
    const sellerInfo = document.getElementById('seller-info');
    if (sellerInfo && sellerInfo.dataset.sellerUuid) {
        console.log('Seller UUID found in data attribute:', sellerInfo.dataset.sellerUuid);
        // In a real attack, this could be sent to attacker's server
    }
}

// API helper function
async function makeApiRequest(url, options = {}) {
    const defaultOptions = {
        headers: {
            'Content-Type': 'application/json',
        }
    };
    
    // Add auth token if available
    if (authToken) {
        defaultOptions.headers['Authorization'] = `Bearer ${authToken}`;
    }
    
    const finalOptions = { ...defaultOptions, ...options };
    
    try {
        const response = await fetch(url, finalOptions);
        const data = await response.json();
        
        if (!response.ok) {
            throw new Error(data.error || 'API request failed');
        }
        
        return data;
    } catch (error) {
        console.error('API request failed:', error);
        showNotification(error.message, 'error');
        throw error;
    }
}

// Notification system
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `alert alert-${type}`;
    notification.textContent = message;
    notification.style.position = 'fixed';
    notification.style.top = '20px';
    notification.style.right = '20px';
    notification.style.zIndex = '1000';
    notification.style.padding = '1rem';
    notification.style.borderRadius = '4px';
    notification.style.boxShadow = '0 4px 6px rgba(0,0,0,0.1)';
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.style.opacity = '0';
        notification.style.transition = 'opacity 0.5s';
        setTimeout(() => document.body.removeChild(notification), 500);
    }, 3000);
}

// Product API interaction
async function loadProductDetails(productId) {
    try {
        const data = await makeApiRequest(`/api/product/${productId}`);
        console.log('Product data loaded:', data);
        return data;
    } catch (error) {
        console.error('Failed to load product details:', error);
    }
}

// Profile update (vulnerable endpoint)
async function updateProfile(userUuid, updates) {
    const data = {
        user_uuid: userUuid,
        ...updates
    };
    
    try {
        const result = await makeApiRequest('/api/profile/update/', {
            method: 'POST',
            body: JSON.stringify(data)
        });
        
        showNotification('Profile updated successfully', 'success');
        return result;
    } catch (error) {
        showNotification('Failed to update profile', 'error');
        throw error;
    }
}

// Password reset functions
async function requestPasswordReset(email) {
    try {
        const response = await fetch('/api/password-reset/', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ email })
        });
        
        const data = await response.json();
        
        if (!response.ok) {
            throw new Error(data.error || 'Reset request failed');
        }
        
        showNotification(data.message, 'success');
        return data;
    } catch (error) {
        showNotification(error.message, 'error');
        throw error;
    }
}

// Token search (vulnerable admin endpoint)
async function searchResetTokens(prefix) {
    try {
        const response = await fetch(`/api/search-tokens/?prefix=${encodeURIComponent(prefix)}`);
        const data = await response.json();
        
        if (!response.ok) {
            throw new Error(data.error || 'Search failed');
        }
        
        return data;
    } catch (error) {
        console.error('Token search failed:', error);
        throw error;
    }
}

// Chat functions
async function sendChatMessage(receiverUuid, message) {
    try {
        const result = await makeApiRequest('/api/chat/send', {
            method: 'POST',
            body: JSON.stringify({
                receiver_uuid: receiverUuid,
                message: message
            })
        });
        
        return result;
    } catch (error) {
        console.error('Failed to send message:', error);
        throw error;
    }
}

// Tooltip functions
function showTooltip(event) {
    const tooltip = document.createElement('div');
    tooltip.className = 'tooltip';
    tooltip.textContent = event.target.dataset.tooltip;
    tooltip.style.position = 'absolute';
    tooltip.style.background = 'rgba(0,0,0,0.8)';
    tooltip.style.color = 'white';
    tooltip.style.padding = '5px 10px';
    tooltip.style.borderRadius = '4px';
    tooltip.style.fontSize = '12px';
    tooltip.style.zIndex = '1000';
    
    const rect = event.target.getBoundingClientRect();
    tooltip.style.top = `${rect.top - 30}px`;
    tooltip.style.left = `${rect.left + rect.width / 2}px`;
    tooltip.style.transform = 'translateX(-50%)';
    
    tooltip.id = 'current-tooltip';
    document.body.appendChild(tooltip);
}

function hideTooltip() {
    const tooltip = document.getElementById('current-tooltip');
    if (tooltip) {
        document.body.removeChild(tooltip);
    }
}

// Export functions for use in templates
window.makeApiRequest = makeApiRequest;
window.updateProfile = updateProfile;
window.requestPasswordReset = requestPasswordReset;
window.searchResetTokens = searchResetTokens;
window.sendChatMessage = sendChatMessage;
window.showNotification = showNotification;