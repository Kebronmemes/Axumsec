-- E-Commerce Database Schema
-- Complete with all necessary tables

-- Users table
CREATE TABLE IF NOT EXISTS users (
    uuid TEXT PRIMARY KEY,
    email TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    name TEXT NOT NULL,
    phone TEXT,
    mfa_enabled INTEGER DEFAULT 0,
    created_at TEXT NOT NULL
);

-- Products table
CREATE TABLE IF NOT EXISTS products (
    uuid TEXT PRIMARY KEY,
    seller_uuid TEXT NOT NULL,
    title TEXT NOT NULL,
    description TEXT,
    price REAL NOT NULL,
    category TEXT,
    image_url TEXT,
    rating REAL DEFAULT 0,
    featured INTEGER DEFAULT 0,
    stock INTEGER DEFAULT 10,
    created_at TEXT NOT NULL,
    FOREIGN KEY (seller_uuid) REFERENCES users(uuid)
);

-- Authentication tokens
CREATE TABLE IF NOT EXISTS auth_tokens (
    token TEXT PRIMARY KEY,
    user_uuid TEXT NOT NULL,
    expires_at TEXT NOT NULL,
    is_revoked INTEGER DEFAULT 0,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_uuid) REFERENCES users(uuid)
);

-- Password reset tokens
CREATE TABLE IF NOT EXISTS reset_tokens (
    token TEXT PRIMARY KEY,
    user_uuid TEXT NOT NULL,
    expires_at TEXT NOT NULL,
    used INTEGER DEFAULT 0,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_uuid) REFERENCES users(uuid)
);

-- Shopping cart
CREATE TABLE IF NOT EXISTS cart_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_uuid TEXT NOT NULL,
    product_uuid TEXT NOT NULL,
    quantity INTEGER DEFAULT 1,
    added_at TEXT NOT NULL,
    FOREIGN KEY (user_uuid) REFERENCES users(uuid),
    FOREIGN KEY (product_uuid) REFERENCES products(uuid)
);

-- Orders
CREATE TABLE IF NOT EXISTS orders (
    uuid TEXT PRIMARY KEY,
    user_uuid TEXT NOT NULL,
    total_amount REAL NOT NULL,
    status TEXT DEFAULT 'pending',
    shipping_address TEXT,
    payment_method TEXT,
    created_at TEXT NOT NULL,
    FOREIGN KEY (user_uuid) REFERENCES users(uuid)
);

-- Order items
CREATE TABLE IF NOT EXISTS order_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    order_uuid TEXT NOT NULL,
    product_uuid TEXT NOT NULL,
    quantity INTEGER NOT NULL,
    price REAL NOT NULL,
    FOREIGN KEY (order_uuid) REFERENCES orders(uuid),
    FOREIGN KEY (product_uuid) REFERENCES products(uuid)
);

-- Chat messages
CREATE TABLE IF NOT EXISTS chat_messages (
    uuid TEXT PRIMARY KEY,
    sender_uuid TEXT NOT NULL,
    receiver_uuid TEXT NOT NULL,
    message TEXT NOT NULL,
    created_at TEXT NOT NULL,
    FOREIGN KEY (sender_uuid) REFERENCES users(uuid),
    FOREIGN KEY (receiver_uuid) REFERENCES users(uuid)
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_products_seller ON products(seller_uuid);
CREATE INDEX IF NOT EXISTS idx_products_category ON products(category);
CREATE INDEX IF NOT EXISTS idx_cart_user ON cart_items(user_uuid);
CREATE INDEX IF NOT EXISTS idx_orders_user ON orders(user_uuid);
CREATE INDEX IF NOT EXISTS idx_chat_participants ON chat_messages(sender_uuid, receiver_uuid);
CREATE INDEX IF NOT EXISTS idx_auth_tokens_user ON auth_tokens(user_uuid);
CREATE INDEX IF NOT EXISTS idx_reset_tokens_user ON reset_tokens(user_uuid);
CREATE INDEX IF NOT EXISTS idx_reset_tokens_expiry ON reset_tokens(expires_at);