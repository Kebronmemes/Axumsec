"""
Database initialization with sample data
"""

import sqlite3
import uuid
import hashlib
from datetime import datetime, timedelta

def init_database():
    """Initialize database with sample data."""
    conn = sqlite3.connect('ecommerce.db')
    cursor = conn.cursor()
    
    # Create tables
    with open('database_schema.sql', 'r') as f:
        schema = f.read()
    cursor.executescript(schema)
    
    # Check if data exists
    cursor.execute("SELECT COUNT(*) FROM users")
    if cursor.fetchone()[0] == 0:
        print("Creating sample data...")
        
        # Create users
        users = [
            {
                'email': 'alice@example.com',
                'password': 'Alice123!',
                'name': 'Alice Johnson',
                'phone': '+1-555-0101',
                'mfa': 1
            },
            {
                'email': 'bob@example.com',
                'password': 'Bob123!',
                'name': 'Bob Smith',
                'phone': '+1-555-0102',
                'mfa': 0
            },
            {
                'email': 'charlie@example.com',
                'password': 'Charlie123!',
                'name': 'Charlie Brown',
                'phone': '+1-555-0103',
                'mfa': 1
            },
            {
                'email': 'diana@example.com',
                'password': 'Diana123!',
                'name': 'Diana Prince',
                'phone': '+1-555-0104',
                'mfa': 0
            }
        ]
        
        user_uuids = {}
        for user in users:
            user_uuid = str(uuid.uuid4())
            user_uuids[user['email']] = user_uuid
            password_hash = hashlib.sha256(user['password'].encode()).hexdigest()
            
            cursor.execute(
                "INSERT INTO users (uuid, email, password_hash, name, phone, mfa_enabled, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
                (user_uuid, user['email'], password_hash, user['name'], user['phone'], user['mfa'], datetime.utcnow().isoformat())
            )
        
        # Create products - FIXED: Now includes category column
        products = [
            {
                'seller': 'alice@example.com',
                'title': 'MacBook Pro 16" 2023',
                'description': 'Apple MacBook Pro with M3 Pro chip, 32GB RAM, 1TB SSD. Perfect for developers and creatives.',
                'price': 2499.99,
                'category': 'Electronics',
                'image_url': 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=400',
                'featured': 1
            },
            {
                'seller': 'bob@example.com',
                'title': 'Sony WH-1000XM5 Headphones',
                'description': 'Industry-leading noise cancellation with premium sound quality. Includes carrying case.',
                'price': 329.99,
                'category': 'Electronics',
                'image_url': 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400',
                'featured': 1
            },
            {
                'seller': 'charlie@example.com',
                'title': 'PlayStation 5 Digital Edition',
                'description': 'Next-gen gaming console with ultra-high speed SSD and immersive 3D audio.',
                'price': 449.99,
                'category': 'Gaming',
                'image_url': 'https://images.unsplash.com/photo-1606144042614-b2417e99c4e3?w=400',
                'featured': 1
            },
            {
                'seller': 'alice@example.com',
                'title': 'iPhone 15 Pro 256GB',
                'description': 'Titanium design, A17 Pro chip, and the longest optical zoom in iPhone.',
                'price': 1099.99,
                'category': 'Electronics',
                'image_url': 'https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=400',
                'featured': 1
            },
            {
                'seller': 'diana@example.com',
                'title': 'Nike Air Max 270',
                'description': 'Comfortable sneakers with Max Air cushioning. Perfect for everyday wear.',
                'price': 149.99,
                'category': 'Fashion',
                'image_url': 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400'
            },
            {
                'seller': 'bob@example.com',
                'title': 'KitchenAid Stand Mixer',
                'description': 'Professional 5-quart stand mixer with 10 speeds. Includes dough hook, flat beater, and wire whip.',
                'price': 399.99,
                'category': 'Home',
                'image_url': 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=400'
            },
            {
                'seller': 'charlie@example.com',
                'title': 'Canon EOS R5 Camera',
                'description': 'Full-frame mirrorless camera with 45MP sensor and 8K video recording.',
                'price': 3899.99,
                'category': 'Electronics',
                'image_url': 'https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=400'
            },
            {
                'seller': 'diana@example.com',
                'title': 'Yoga Mat Premium',
                'description': 'Eco-friendly yoga mat with excellent grip and cushioning. Includes carrying strap.',
                'price': 49.99,
                'category': 'Sports',
                'image_url': 'https://images.unsplash.com/photo-1599901860904-17e6ed7083a0?w=400'
            }
        ]
        
        for product in products:
            product_uuid = str(uuid.uuid4())
            seller_uuid = user_uuids[product['seller']]
            
            cursor.execute(
                '''INSERT INTO products (uuid, seller_uuid, title, description, price, 
                    category, image_url, featured, stock, created_at) 
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                (product_uuid, seller_uuid, product['title'], product['description'],
                 product['price'], product['category'], product['image_url'],
                 product.get('featured', 0), 10, datetime.utcnow().isoformat())
            )
        
        # Create sample chat messages
        cursor.execute(
            '''INSERT INTO chat_messages (uuid, sender_uuid, receiver_uuid, message, created_at)
               VALUES (?, ?, ?, ?, ?)''',
            (str(uuid.uuid4()), user_uuids['alice@example.com'], user_uuids['bob@example.com'],
             'Hi Bob, is the Sony headphone still available?', 
             (datetime.utcnow() - timedelta(hours=2)).isoformat())
        )
        
        cursor.execute(
            '''INSERT INTO chat_messages (uuid, sender_uuid, receiver_uuid, message, created_at)
               VALUES (?, ?, ?, ?, ?)''',
            (str(uuid.uuid4()), user_uuids['bob@example.com'], user_uuids['alice@example.com'],
             'Yes, it\'s available! Would you like to make an offer?',
             (datetime.utcnow() - timedelta(hours=1)).isoformat())
        )
        
        conn.commit()
        print("✅ Sample data created successfully!")
        print("\n👤 Test Users:")
        for user in users:
            print(f"   📧 {user['email']} / {user['password']}")
        
        print("\n🛒 Products created: 8 items across 4 categories")
    
    conn.close()

if __name__ == '__main__':
    init_database()