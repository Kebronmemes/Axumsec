import os
import sqlite3
import uuid
import hashlib
import time
import json
import smtplib
from datetime import datetime, timedelta
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from functools import wraps
from flask import Flask, render_template, request, jsonify, session, redirect, url_for, g, flash

app = Flask(__name__)

app.secret_key = os.environ.get('SECRET_KEY', os.urandom(32).hex())
app.config['DATABASE'] = 'ecommerce.db'
app.config['SMTP_HOST'] = 'localhost'
app.config['SMTP_PORT'] = 1025

def get_reset_secret():
    db = get_db()
    secret = db.execute('SELECT value FROM app_config WHERE key = "reset_secret"').fetchone()
    
    if not secret:
        import secrets
        new_secret = secrets.token_urlsafe(32)
        pepper = secrets.token_hex(16)
        
        db.execute('''
            INSERT INTO app_config (key, value) 
            VALUES ('reset_secret', ?), ('reset_pepper', ?)
        ''', (new_secret, pepper))
        db.commit()
        
        return new_secret, pepper
    
    pepper = db.execute('SELECT value FROM app_config WHERE key = "reset_pepper"').fetchone()
    return secret['value'], pepper['value'] if pepper else ''

def get_db():
    if 'db' not in g:
        g.db = sqlite3.connect(app.config['DATABASE'])
        g.db.row_factory = sqlite3.Row
    return g.db

@app.teardown_appcontext
def close_db(error):
    db = g.pop('db', None)
    if db is not None:
        db.close()

def generate_reset_token(user_uuid, user_email):
    timestamp = int(time.time())
    email_hash = hashlib.md5(user_email.encode()).hexdigest()
    raw_token = f"{user_uuid}{timestamp}{email_hash}"
    
    token = hashlib.sha256(raw_token.encode()).hexdigest()
    
    db = get_db()
    expires = datetime.utcnow() + timedelta(hours=1)
    
    db.execute(
        'INSERT INTO reset_tokens (token, user_uuid, expires_at, used) VALUES (?, ?, ?, 0)',
        (token, user_uuid, expires.isoformat())
    )
    db.commit()
    
    return token, timestamp

def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_uuid' not in session:
            flash('Please login first', 'warning')
            return redirect(url_for('login', next=request.url))
        return f(*args, **kwargs)
    return decorated

def send_email(to_email, subject, body):
    try:
        msg = MIMEMultipart()
        msg['From'] = 'noreply@shopsecure.com'
        msg['To'] = to_email
        msg['Subject'] = subject
        msg.attach(MIMEText(body, 'html'))
        
        with smtplib.SMTP(app.config['SMTP_HOST'], app.config['SMTP_PORT']) as server:
            server.send_message(msg)
        return True
    except Exception as e:
        print(f"Email error: {e}")
        return False

@app.route('/')
def index():
    db = get_db()
    featured_products = db.execute('''
        SELECT p.*, u.name as seller_name 
        FROM products p 
        JOIN users u ON p.seller_uuid = u.uuid
        WHERE p.featured = 1
        ORDER BY p.created_at DESC 
        LIMIT 8
    ''').fetchall()
    
    return render_template('index.html', featured_products=featured_products)

@app.route('/products')
def products():
    db = get_db()
    category = request.args.get('category', '')
    search = request.args.get('search', '')
    sort = request.args.get('sort', 'newest')
    
    query = '''
        SELECT p.*, u.name as seller_name, u.uuid as seller_uuid
        FROM products p 
        JOIN users u ON p.seller_uuid = u.uuid
        WHERE 1=1
    '''
    params = []
    
    if category:
        query += ' AND p.category = ?'
        params.append(category)
    
    if search:
        query += ' AND (p.title LIKE ? OR p.description LIKE ?)'
        params.extend([f'%{search}%', f'%{search}%'])
    
    if sort == 'price_low':
        query += ' ORDER BY p.price ASC'
    elif sort == 'price_high':
        query += ' ORDER BY p.price DESC'
    elif sort == 'rating':
        query += ' ORDER BY p.rating DESC'
    else:
        query += ' ORDER BY p.created_at DESC'
    
    products_data = db.execute(query, params).fetchall()
    categories = db.execute('SELECT DISTINCT category FROM products WHERE category IS NOT NULL').fetchall()
    
    return render_template('products.html', 
                         products=products_data,
                         categories=categories,
                         current_category=category,
                         current_search=search,
                         current_sort=sort)

@app.route('/product/<product_uuid>')
def product_detail(product_uuid):
    db = get_db()
    product = db.execute('''
        SELECT p.*, u.name as seller_name, u.uuid as seller_uuid
        FROM products p 
        JOIN users u ON p.seller_uuid = u.uuid
        WHERE p.uuid = ?
    ''', (product_uuid,)).fetchone()
    
    if not product:
        flash('Product not found', 'error')
        return redirect(url_for('products'))
    
    related_products = db.execute('''
        SELECT p.*, u.name as seller_name
        FROM products p 
        JOIN users u ON p.seller_uuid = u.uuid
        WHERE p.category = ? AND p.uuid != ?
        LIMIT 4
    ''', (product['category'], product_uuid)).fetchall()
    
    return render_template('product_detail.html', 
                         product=product,
                         related_products=related_products)

@app.route('/profile', methods=['GET', 'POST'])
@login_required
def profile():
    db = get_db()
    
    if request.method == 'POST':
        name = request.form.get('name')
        email = request.form.get('email')
        phone = request.form.get('phone')
        
        if email != session.get('user_email'):
            existing = db.execute('SELECT uuid FROM users WHERE email = ? AND uuid != ?', 
                                (email, session['user_uuid'])).fetchone()
            if existing:
                flash('Email already registered by another user', 'error')
                return redirect(url_for('profile'))
        
        db.execute('''
            UPDATE users 
            SET name = ?, email = ?, phone = ?
            WHERE uuid = ?
        ''', (name, email, phone, session['user_uuid']))
        db.commit()
        
        session['user_name'] = name
        session['user_email'] = email
        
        flash('Profile updated successfully!', 'success')
        return redirect(url_for('profile'))
    
    user = db.execute('''
        SELECT uuid, email, name, phone, created_at
        FROM users WHERE uuid = ?
    ''', (session['user_uuid'],)).fetchone()
    
    return render_template('profile.html', user=user)

@app.route('/cart')
@login_required
def cart():
    db = get_db()
    cart_items = db.execute('''
        SELECT ci.*, p.title, p.image_url, p.price as unit_price, 
               u.name as seller_name
        FROM cart_items ci
        JOIN products p ON ci.product_uuid = p.uuid
        JOIN users u ON p.seller_uuid = u.uuid
        WHERE ci.user_uuid = ?
    ''', (session['user_uuid'],)).fetchall()
    
    subtotal = sum(item['quantity'] * item['unit_price'] for item in cart_items)
    shipping = 5.99 if subtotal > 0 else 0
    tax = subtotal * 0.08
    total = subtotal + shipping + tax
    
    return render_template('cart.html', 
                         cart_items=cart_items,
                         subtotal=subtotal,
                         shipping=shipping,
                         tax=tax,
                         total=total)

@app.route('/checkout', methods=['GET', 'POST'])
@login_required
def checkout():
    db = get_db()
    cart_items = db.execute('''
        SELECT ci.*, p.title, p.price as unit_price
        FROM cart_items ci
        JOIN products p ON ci.product_uuid = p.uuid
        WHERE ci.user_uuid = ?
    ''', (session['user_uuid'],)).fetchall()
    
    if not cart_items:
        flash('Your cart is empty', 'warning')
        return redirect(url_for('cart'))
    
    subtotal = sum(item['quantity'] * item['unit_price'] for item in cart_items)
    shipping = 5.99
    tax = subtotal * 0.08
    total = subtotal + shipping + tax
    
    if request.method == 'POST':
        name = request.form.get('name')
        address = request.form.get('address')
        city = request.form.get('city')
        state = request.form.get('state')
        zip_code = request.form.get('zip_code')
        payment_method = request.form.get('payment_method')
        
        order_uuid = str(uuid.uuid4())
        db.execute('''
            INSERT INTO orders (uuid, user_uuid, total_amount, status, 
                              shipping_address, payment_method, created_at)
            VALUES (?, ?, ?, 'pending', ?, ?, ?)
        ''', (order_uuid, session['user_uuid'], total, 
              f"{address}, {city}, {state} {zip_code}", 
              payment_method, datetime.utcnow().isoformat()))
        
        for item in cart_items:
            db.execute('''
                INSERT INTO order_items (order_uuid, product_uuid, quantity, price)
                VALUES (?, ?, ?, ?)
            ''', (order_uuid, item['product_uuid'], item['quantity'], item['unit_price']))
        
        db.execute('DELETE FROM cart_items WHERE user_uuid = ?', (session['user_uuid'],))
        db.commit()
        
        flash('Order placed successfully!', 'success')
        return redirect(url_for('order_confirmation', order_uuid=order_uuid))
    
    user = db.execute('SELECT name, email FROM users WHERE uuid = ?', 
                     (session['user_uuid'],)).fetchone()
    
    return render_template('checkout.html',
                         cart_items=cart_items,
                         subtotal=subtotal,
                         shipping=shipping,
                         tax=tax,
                         total=total,
                         user=user)

@app.route('/order/<order_uuid>')
@login_required
def order_confirmation(order_uuid):
    db = get_db()
    order = db.execute('''
        SELECT o.*, 
               COUNT(oi.id) as item_count,
               GROUP_CONCAT(p.title) as product_names
        FROM orders o
        LEFT JOIN order_items oi ON o.uuid = oi.order_uuid
        LEFT JOIN products p ON oi.product_uuid = p.uuid
        WHERE o.uuid = ? AND o.user_uuid = ?
        GROUP BY o.uuid
    ''', (order_uuid, session['user_uuid'])).fetchone()
    
    if not order:
        flash('Order not found', 'error')
        return redirect(url_for('profile'))
    
    return render_template('order_confirmation.html', order=order)

@app.route('/orders')
@login_required
def orders():
    db = get_db()
    user_orders = db.execute('''
        SELECT o.*, 
               COUNT(oi.id) as item_count,
               SUM(oi.quantity * oi.price) as total
        FROM orders o
        LEFT JOIN order_items oi ON o.uuid = oi.order_uuid
        WHERE o.user_uuid = ?
        GROUP BY o.uuid
        ORDER BY o.created_at DESC
    ''', (session['user_uuid'],)).fetchall()
    
    return render_template('orders.html', orders=user_orders)

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')
        name = request.form.get('name')
        phone = request.form.get('phone')
        
        if not email or not password or not name:
            flash('Please fill in all required fields', 'error')
            return redirect(url_for('register'))
        
        if password != confirm_password:
            flash('Passwords do not match', 'error')
            return redirect(url_for('register'))
        
        db = get_db()
        existing = db.execute('SELECT uuid FROM users WHERE email = ?', (email,)).fetchone()
        if existing:
            flash('Email already registered', 'error')
            return redirect(url_for('register'))
        
        user_uuid = str(uuid.uuid4())
        password_hash = hashlib.sha256(password.encode()).hexdigest()
        
        db.execute('''
            INSERT INTO users (uuid, email, password_hash, name, phone, created_at)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (user_uuid, email, password_hash, name, phone, datetime.utcnow().isoformat()))
        db.commit()
        
        flash('Registration successful! Please login.', 'success')
        return redirect(url_for('login'))
    
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        
        if not email or not password:
            flash('Please enter email and password', 'error')
            return redirect(url_for('login'))
        
        db = get_db()
        user = db.execute('SELECT * FROM users WHERE email = ?', (email,)).fetchone()
        
        if not user:
            time.sleep(0.1)
            flash('Invalid email or password', 'error')
            return redirect(url_for('login'))
        
        password_hash = hashlib.sha256(password.encode()).hexdigest()
        if password_hash != user['password_hash']:
            flash('Invalid email or password', 'error')
            return redirect(url_for('login'))
        
        session['user_uuid'] = user['uuid']
        session['user_name'] = user['name']
        session['user_email'] = user['email']
        
        flash(f'Welcome back, {user["name"]}!', 'success')
        return redirect(url_for('index'))
    
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    flash('You have been logged out', 'info')
    return redirect(url_for('index'))

@app.route('/forgot-password')
def forgot_password():
    return render_template('reset_password.html')

@app.route('/reset')
def reset_password_confirm():
    token = request.args.get('token')
    return render_template('reset_confirm.html', token=token)

@app.route('/api/v1/products', methods=['GET'])
def api_get_products():
    db = get_db()
    limit = request.args.get('limit', 20, type=int)
    offset = request.args.get('offset', 0, type=int)
    
    products = db.execute('''
        SELECT p.uuid, p.title, p.description, p.price, p.category,
               u.name as seller_name, u.uuid as seller_uuid
        FROM products p 
        JOIN users u ON p.seller_uuid = u.uuid
        LIMIT ? OFFSET ?
    ''', (limit, offset)).fetchall()
    
    total = db.execute('SELECT COUNT(*) as count FROM products').fetchone()['count']
    
    return jsonify({
        'success': True,
        'data': [dict(p) for p in products],
        'pagination': {
            'total': total,
            'limit': limit,
            'offset': offset,
            'has_more': offset + len(products) < total
        }
    })

@app.route('/api/v1/product/<product_uuid>', methods=['GET'])
def api_get_product(product_uuid):
    db = get_db()
    product = db.execute('''
        SELECT p.*, u.name as seller_name, u.uuid as seller_uuid
        FROM products p 
        JOIN users u ON p.seller_uuid = u.uuid
        WHERE p.uuid = ?
    ''', (product_uuid,)).fetchone()
    
    if not product:
        return jsonify({'success': False, 'error': 'Product not found'}), 404
    
    return jsonify({
        'success': True,
        'data': dict(product)
    })

@app.route('/api/v1/categories', methods=['GET'])
def api_get_categories():
    db = get_db()
    categories = db.execute('''
        SELECT category, COUNT(*) as product_count
        FROM products 
        WHERE category IS NOT NULL
        GROUP BY category
        ORDER BY category
    ''').fetchall()
    
    return jsonify({
        'success': True,
        'data': [dict(c) for c in categories]
    })

@app.route('/api/v1/password-reset', methods=['POST'])
def api_password_reset():
    data = request.get_json()
    email = data.get('email', '').strip().lower()
    
    if not email:
        return jsonify({'success': False, 'error': 'Email required'}), 400
    
    db = get_db()
    user = db.execute('SELECT uuid, email FROM users WHERE email = ?', (email,)).fetchone()
    
    if not user:
        time.sleep(0.15)
        return jsonify({
            'success': True,
            'message': 'If the email exists, reset instructions have been sent.'
        })
    
    token, timestamp = generate_reset_token(user['uuid'], user['email'])
    
    reset_link = f"http://localhost:8000/reset?token={token}"
    email_body = f"""
    <h1>Password Reset Request</h1>
    <p>Click the link below to reset your password:</p>
    <p><a href="{reset_link}">Reset Password</a></p>
    <p>Or use this token: {token}</p>
    <p><small>Requested at: {datetime.fromtimestamp(timestamp).strftime('%Y-%m-%d %H:%M:%S')}</small></p>
    """
    
    send_email(email, 'Password Reset - ShopSecure', email_body)
    
    return jsonify({
        'success': True,
        'message': 'If the email exists, reset instructions have been sent.'
    })

@app.route('/api/v1/password-reset/validate', methods=['POST'])
def api_validate_token():
    data = request.get_json()
    token = data.get('token', '')
    
    if len(token) != 64:
        time.sleep(0.05)
        return jsonify({'valid': False}), 400
    
    db = get_db()
    reset = db.execute('''
        SELECT user_uuid, expires_at, used 
        FROM reset_tokens 
        WHERE token = ? AND expires_at > ?
    ''', (token, datetime.utcnow().isoformat())).fetchone()
    
    if not reset or reset['used']:
        time.sleep(0.1)
        return jsonify({'valid': False}), 400
    
    return jsonify({'valid': True})

@app.route('/api/v1/password-reset/confirm', methods=['POST'])
def api_confirm_reset():
    data = request.get_json()
    token = data.get('token')
    new_password = data.get('new_password')
    
    if not token or not new_password:
        return jsonify({'success': False, 'error': 'Token and password required'}), 400
    
    db = get_db()
    reset = db.execute('''
        SELECT user_uuid 
        FROM reset_tokens 
        WHERE token = ? AND expires_at > ? AND used = 0
    ''', (token, datetime.utcnow().isoformat())).fetchone()
    
    if not reset:
        return jsonify({'success': False, 'error': 'Invalid or expired token'}), 400
    
    password_hash = hashlib.sha256(new_password.encode()).hexdigest()
    db.execute('UPDATE users SET password_hash = ? WHERE uuid = ?',
              (password_hash, reset['user_uuid']))
    db.execute('UPDATE reset_tokens SET used = 1 WHERE token = ?', (token,))
    db.commit()
    
    return jsonify({
        'success': True,
        'message': 'Password updated successfully'
    })

@app.route('/api/v1/stats', methods=['GET'])
def api_get_stats():
    db = get_db()
    stats = {
        'total_users': db.execute('SELECT COUNT(*) as count FROM users').fetchone()['count'],
        'total_products': db.execute('SELECT COUNT(*) as count FROM products').fetchone()['count'],
        'total_orders': db.execute('SELECT COUNT(*) as count FROM orders').fetchone()['count'],
        'active_resets': db.execute('SELECT COUNT(*) as count FROM reset_tokens WHERE expires_at > ?', 
                                   (datetime.utcnow().isoformat(),)).fetchone()['count']
    }
    
    return jsonify({
        'success': True,
        'data': stats
    })

@app.route('/api/v1/search', methods=['GET'])
def api_search():
    query = request.args.get('q', '')
    
    if not query:
        return jsonify({'success': False, 'error': 'Search query required'}), 400
    
    db = get_db()
    products = db.execute('''
        SELECT p.uuid, p.title, p.price, p.category,
               u.name as seller_name, u.uuid as seller_uuid
        FROM products p 
        JOIN users u ON p.seller_uuid = u.uuid
        WHERE p.title LIKE ? OR p.description LIKE ?
        LIMIT 10
    ''', (f'%{query}%', f'%{query}%')).fetchall()
    
    if not products:
        time.sleep(0.1)
    
    return jsonify({
        'success': True,
        'data': {
            'products': [dict(p) for p in products],
            'product_count': len(products)
        }
    })

@app.errorhandler(404)
def not_found(error):
    if request.path.startswith('/api/'):
        return jsonify({'success': False, 'error': 'Endpoint not found'}), 404
    return render_template('error.html', error='Page not found'), 404

@app.errorhandler(500)
def internal_error(error):
    if request.path.startswith('/api/'):
        return jsonify({'success': False, 'error': 'Internal server error'}), 500
    return render_template('error.html', error='Internal server error'), 500

@app.route('/chat/<seller_uuid>')
@login_required
def chat(seller_uuid):
    db = get_db()
    seller = db.execute('''
        SELECT uuid, name, email 
        FROM users 
        WHERE uuid = ?
    ''', (seller_uuid,)).fetchone()
    
    if not seller:
        flash('Seller not found', 'error')
        return redirect(url_for('products'))
    
    return render_template('chat.html', seller=seller)

@app.route('/api/v1/profile/<user_uuid>', methods=['GET'])
@login_required
def api_get_user_profile(user_uuid):
    db = get_db()
    user = db.execute('''
        SELECT uuid, email, name, created_at 
        FROM users WHERE uuid = ?
    ''', (user_uuid,)).fetchone()
    
    if not user:
        return jsonify({'success': False, 'error': 'User not found'}), 404
    
    return jsonify({
        'success': True,
        'data': dict(user),
        'warning': 'This endpoint should require authorization!'
    })

@app.route('/api/docs')
def api_docs():
    return render_template('api_docs.html')

def init_database():
    conn = sqlite3.connect('ecommerce.db')
    try:
        with open('database_schema.sql', 'r') as f:
            schema = f.read()
    except FileNotFoundError:
        schema = '''
        CREATE TABLE IF NOT EXISTS users (
            uuid TEXT PRIMARY KEY,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            name TEXT NOT NULL,
            phone TEXT,
            created_at TIMESTAMP NOT NULL
        );
        
        CREATE TABLE IF NOT EXISTS products (
            uuid TEXT PRIMARY KEY,
            title TEXT NOT NULL,
            description TEXT,
            price REAL NOT NULL,
            category TEXT,
            image_url TEXT,
            seller_uuid TEXT NOT NULL,
            featured INTEGER DEFAULT 0,
            rating REAL DEFAULT 0,
            created_at TIMESTAMP NOT NULL,
            FOREIGN KEY (seller_uuid) REFERENCES users(uuid)
        );
        
        CREATE TABLE IF NOT EXISTS cart_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_uuid TEXT NOT NULL,
            product_uuid TEXT NOT NULL,
            quantity INTEGER NOT NULL DEFAULT 1,
            added_at TIMESTAMP NOT NULL,
            FOREIGN KEY (user_uuid) REFERENCES users(uuid),
            FOREIGN KEY (product_uuid) REFERENCES products(uuid)
        );
        
        CREATE TABLE IF NOT EXISTS orders (
            uuid TEXT PRIMARY KEY,
            user_uuid TEXT NOT NULL,
            total_amount REAL NOT NULL,
            status TEXT NOT NULL,
            shipping_address TEXT NOT NULL,
            payment_method TEXT NOT NULL,
            created_at TIMESTAMP NOT NULL,
            FOREIGN KEY (user_uuid) REFERENCES users(uuid)
        );
        
        CREATE TABLE IF NOT EXISTS order_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            order_uuid TEXT NOT NULL,
            product_uuid TEXT NOT NULL,
            quantity INTEGER NOT NULL,
            price REAL NOT NULL,
            FOREIGN KEY (order_uuid) REFERENCES orders(uuid),
            FOREIGN KEY (product_uuid) REFERENCES products(uuid)
        );
        '''
    
    schema += '''
    CREATE TABLE IF NOT EXISTS app_config (
        key TEXT PRIMARY KEY,
        value TEXT NOT NULL,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
    
    CREATE TABLE IF NOT EXISTS reset_tokens (
        token TEXT PRIMARY KEY,
        user_uuid TEXT NOT NULL,
        expires_at TIMESTAMP NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        used INTEGER DEFAULT 0,
        FOREIGN KEY (user_uuid) REFERENCES users(uuid)
    );
    '''
    
    conn.executescript(schema)
    cursor = conn.cursor()
    
    cursor.execute("SELECT COUNT(*) as count FROM users WHERE email IN ('alice@example.com', 'bob@example.com', 'charlie@example.com', 'admin@example.com')")
    count = cursor.fetchone()[0]
    
    if count == 0:
        users = [
            ('alice@example.com', 'Alice123!', 'Alice Johnson', '555-0101'),
            ('bob@example.com', 'Bob123!', 'Bob Smith', '555-0102'),
            ('charlie@example.com', 'Charlie123!', 'Charlie Brown', '555-0103'),
            ('admin@example.com', 'Admin123!', 'Administrator', '555-0000')
        ]
        
        for email, password, name, phone in users:
            user_uuid = str(uuid.uuid4())
            password_hash = hashlib.sha256(password.encode()).hexdigest()
            
            cursor.execute('''
                INSERT OR IGNORE INTO users (uuid, email, password_hash, name, phone, created_at)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (user_uuid, email, password_hash, name, phone, datetime.utcnow().isoformat()))
            
            if email == 'alice@example.com':
                for i in range(3):
                    product_uuid = str(uuid.uuid4())
                    cursor.execute('''
                        INSERT INTO products (uuid, title, description, price, category, seller_uuid, created_at)
                        VALUES (?, ?, ?, ?, ?, ?, ?)
                    ''', (
                        product_uuid,
                        f'Product {i+1} from Alice',
                        f'Description for product {i+1}',
                        19.99 + i * 10,
                        'Electronics',
                        user_uuid,
                        datetime.utcnow().isoformat()
                    ))
            
            if email == 'bob@example.com':
                for i in range(2):
                    product_uuid = str(uuid.uuid4())
                    cursor.execute('''
                        INSERT INTO products (uuid, title, description, price, category, seller_uuid, created_at)
                        VALUES (?, ?, ?, ?, ?, ?, ?)
                    ''', (
                        product_uuid,
                        f'Product {i+1} from Bob',
                        f'Description for product {i+1}',
                        29.99 + i * 5,
                        'Home & Garden',
                        user_uuid,
                        datetime.utcnow().isoformat()
                    ))
    
    conn.commit()
    conn.close()

if __name__ == '__main__':
    init_database()
    
    print("="*60)
    print("Shop Secure E-Commerce Platform")
    print("="*60)
    print("Application is running!")
    print(f"Website: http://localhost:8000")
    print(f"Email Interface: http://localhost:8025")
    
    print("\nTest Accounts:")
    print("alice@example.com / Alice123!")
    print("bob@example.com / Bob123!")
    print("charlie@example.com / Charlie123!")
    print("admin@example.com / Admin123!")
    
    print("enjoy your stay")   
    app.run(host='0.0.0.0', port=8000, debug=True)