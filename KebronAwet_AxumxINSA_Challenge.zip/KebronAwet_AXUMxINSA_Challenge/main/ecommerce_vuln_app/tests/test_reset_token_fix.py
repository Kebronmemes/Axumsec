import re
from app import generate_reset_token, app


def test_generate_reset_token_entropy():
    t1 = generate_reset_token('11111111-1111-1111-1111-111111111111')
    t2 = generate_reset_token('11111111-1111-1111-1111-111111111111')
    assert t1 != t2
    assert len(t1) >= 16
    assert re.match(r'^[A-Za-z0-9_\-]+$', t1)


def test_password_reset_no_timestamp():
    client = app.test_client()
    resp = client.post('/api/v1/password-reset', json={'email': 'alice@example.com'})
    assert resp.status_code == 200
    data = resp.get_json()
    assert data.get('success') is True
    # Ensure timestamp is no longer leaked
    assert 'timestamp' not in data
